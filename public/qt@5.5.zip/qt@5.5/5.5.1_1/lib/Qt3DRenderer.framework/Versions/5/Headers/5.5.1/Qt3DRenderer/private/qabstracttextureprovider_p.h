/****************************************************************************
**
** Copyright (C) 2015 Klaralvdalens Datakonsult AB (KDAB).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the Qt3D module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL3$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see http://www.qt.io/terms-conditions. For further
** information use the contact form at http://www.qt.io/contact-us.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 3 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPLv3 included in the
** packaging of this file. Please review the following information to
** ensure the GNU Lesser General Public License version 3 requirements
** will be met: https://www.gnu.org/licenses/lgpl.html.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 2.0 or later as published by the Free
** Software Foundation and appearing in the file LICENSE.GPL included in
** the packaging of this file. Please review the following information to
** ensure the GNU General Public License version 2.0 requirements will be
** met: http://www.gnu.org/licenses/gpl-2.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef QT3D_QABSTRACTTEXTUREPROVIDER_P_H
#define QT3D_QABSTRACTTEXTUREPROVIDER_P_H

#include <Qt3DRenderer/qt3drenderer_global.h>
#include <Qt3DCore/private/qnode_p.h>
#include <Qt3DRenderer/qabstracttextureprovider.h>
#include <Qt3DRenderer/qwrapmode.h>

QT_BEGIN_NAMESPACE

namespace Qt3D {

class QAbstractTextureProviderPrivate : public QNodePrivate
{
public :
    QAbstractTextureProviderPrivate();

    Q_DECLARE_PUBLIC(QAbstractTextureProvider)

    QAbstractTextureProvider::Target m_target;
    QAbstractTextureProvider::TextureFormat m_format;
    int m_width, m_height, m_depth;
    bool m_autoMipMap;

    QList<TexImageDataPtr> m_data;

    QAbstractTextureProvider::Filter m_minFilter, m_magFilter;
    // FIXME, store per direction
    QTextureWrapMode m_wrapMode;
    QAbstractTextureProvider::Status m_status;
    float m_maximumAnisotropy;
    QAbstractTextureProvider::ComparisonFunction m_comparisonFunction;
    QAbstractTextureProvider::ComparisonMode m_comparisonMode;
    QList<QAbstractTextureImage *> m_textureImages;
    int m_maximumLayers;
    bool m_unique;
};

} // QT3D

QT_END_NAMESPACE

#endif // QT3D_QABSTRACTTEXTUREPROVIDER_P_H

